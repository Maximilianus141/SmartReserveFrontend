package ch.kenner.maximilian.smartreserve.controller.service;

import ch.kenner.maximilian.smartreserve.base.MessageResponse;
import ch.kenner.maximilian.smartreserve.model.service.Service;
import ch.kenner.maximilian.smartreserve.model.service.ServiceRepository;


import java.util.List;


@org.springframework.stereotype.Service
public class ServiceService {

    private final ServiceRepository serviceRepository;

    public ServiceService(ServiceRepository serviceRepository) {
        this.serviceRepository = serviceRepository;
    }

    public List<Service> getAllServices() {
        return serviceRepository.findAll();
    }

    public Service getServiceById(Long id) {
        return serviceRepository.findById(id).orElse(null);
    }

    public Service insertService(Service service) {
        return serviceRepository.save(service);
    }

    public Service updateservice(Service service, Long id) {
        return serviceRepository.findById(id)
                .map(serviceOrig -> {
                    serviceOrig.setName(service.getName());
                    serviceOrig.setDescription(service.getDescription());
                    serviceOrig.setDurationSeconds(service.getDurationSeconds());
                    serviceOrig.setAfterServiceBreakDurationSeconds(service.getAfterServiceBreakDurationSeconds());
                    return serviceRepository.save(serviceOrig);
                })
                .orElseGet(() -> {
                    service.setId(id);
                    return serviceRepository.save(service);
                });
    }

    public MessageResponse deleteService(Long id) {
        serviceRepository.deleteById(id);
        return new MessageResponse("Service " + id + " deleted");
    }
}
